--
-- PostgreSQL database dump
--

\restrict zuGNDXh2MSiZRiXW3MXfXvhtLFggfzjUnv1I1teTSCKUxhVDyLVhUJNckoe5DLr

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workout_sessions DROP CONSTRAINT IF EXISTS workout_sessions_workout_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_sessions DROP CONSTRAINT IF EXISTS workout_sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_session_sets DROP CONSTRAINT IF EXISTS workout_session_sets_workout_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_session_sets DROP CONSTRAINT IF EXISTS workout_session_sets_exercise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_plans DROP CONSTRAINT IF EXISTS workout_plans_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_plan_exercises DROP CONSTRAINT IF EXISTS workout_plan_exercises_workout_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_plan_exercises DROP CONSTRAINT IF EXISTS workout_plan_exercises_exercise_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workout_logs DROP CONSTRAINT IF EXISTS workout_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.exercises DROP CONSTRAINT IF EXISTS exercises_category_id_fkey;
DROP INDEX IF EXISTS public.idx_workout_sessions_user_started;
DROP INDEX IF EXISTS public.idx_workout_sessions_plan;
DROP INDEX IF EXISTS public.idx_workout_session_sets_session;
DROP INDEX IF EXISTS public.idx_workout_session_sets_exercise;
DROP INDEX IF EXISTS public.idx_workout_plans_user_id;
DROP INDEX IF EXISTS public.idx_workout_plan_exercises_plan;
DROP INDEX IF EXISTS public.idx_workout_plan_exercises_exercise;
DROP INDEX IF EXISTS public.idx_workout_logs_user_date;
ALTER TABLE IF EXISTS ONLY public.workout_sessions DROP CONSTRAINT IF EXISTS workout_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.workout_session_sets DROP CONSTRAINT IF EXISTS workout_session_sets_workout_session_id_exercise_id_set_num_key;
ALTER TABLE IF EXISTS ONLY public.workout_session_sets DROP CONSTRAINT IF EXISTS workout_session_sets_pkey;
ALTER TABLE IF EXISTS ONLY public.workout_plans DROP CONSTRAINT IF EXISTS workout_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.workout_plan_exercises DROP CONSTRAINT IF EXISTS workout_plan_exercises_workout_plan_id_sort_order_key;
ALTER TABLE IF EXISTS ONLY public.workout_plan_exercises DROP CONSTRAINT IF EXISTS workout_plan_exercises_pkey;
ALTER TABLE IF EXISTS ONLY public.workout_logs DROP CONSTRAINT IF EXISTS workout_logs_user_id_workout_date_key;
ALTER TABLE IF EXISTS ONLY public.workout_logs DROP CONSTRAINT IF EXISTS workout_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.exercises DROP CONSTRAINT IF EXISTS exercises_pkey;
ALTER TABLE IF EXISTS ONLY public.exercises DROP CONSTRAINT IF EXISTS exercises_category_id_name_key;
ALTER TABLE IF EXISTS ONLY public.exercise_categories DROP CONSTRAINT IF EXISTS exercise_categories_slug_key;
ALTER TABLE IF EXISTS ONLY public.exercise_categories DROP CONSTRAINT IF EXISTS exercise_categories_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS public.exercise_categories ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.workout_sessions;
DROP TABLE IF EXISTS public.workout_session_sets;
DROP TABLE IF EXISTS public.workout_plans;
DROP TABLE IF EXISTS public.workout_plan_exercises;
DROP TABLE IF EXISTS public.workout_logs;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.exercises;
DROP SEQUENCE IF EXISTS public.exercise_categories_id_seq;
DROP TABLE IF EXISTS public.exercise_categories;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP EXTENSION IF EXISTS pgcrypto;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: exercise_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercise_categories (
    id smallint NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    CONSTRAINT exercise_categories_name_check CHECK ((char_length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT exercise_categories_slug_check CHECK ((char_length(TRIM(BOTH FROM slug)) > 0))
);


--
-- Name: exercise_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exercise_categories_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exercise_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exercise_categories_id_seq OWNED BY public.exercise_categories.id;


--
-- Name: exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercises (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id smallint,
    name text NOT NULL,
    equipment text,
    is_unilateral boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT exercises_name_check CHECK ((char_length(TRIM(BOTH FROM name)) > 0))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workout_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workout_date date NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workout_logs_description_check CHECK ((char_length(TRIM(BOTH FROM description)) > 0))
);


--
-- Name: workout_plan_exercises; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_plan_exercises (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workout_plan_id uuid NOT NULL,
    exercise_id uuid NOT NULL,
    sort_order integer NOT NULL,
    target_sets integer,
    target_reps_min integer,
    target_reps_max integer,
    target_weight_kg numeric(6,2),
    rest_seconds integer,
    notes text,
    CONSTRAINT workout_plan_exercises_check CHECK (((target_reps_min IS NULL) OR (target_reps_max IS NULL) OR (target_reps_min <= target_reps_max))),
    CONSTRAINT workout_plan_exercises_rest_seconds_check CHECK (((rest_seconds IS NULL) OR (rest_seconds >= 0))),
    CONSTRAINT workout_plan_exercises_sort_order_check CHECK ((sort_order > 0)),
    CONSTRAINT workout_plan_exercises_target_reps_max_check CHECK (((target_reps_max IS NULL) OR (target_reps_max > 0))),
    CONSTRAINT workout_plan_exercises_target_reps_min_check CHECK (((target_reps_min IS NULL) OR (target_reps_min > 0))),
    CONSTRAINT workout_plan_exercises_target_sets_check CHECK (((target_sets IS NULL) OR (target_sets > 0))),
    CONSTRAINT workout_plan_exercises_target_weight_kg_check CHECK (((target_weight_kg IS NULL) OR (target_weight_kg >= (0)::numeric)))
);


--
-- Name: workout_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workout_plans_title_check CHECK ((char_length(TRIM(BOTH FROM title)) > 0))
);


--
-- Name: workout_session_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_session_sets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workout_session_id uuid NOT NULL,
    exercise_id uuid NOT NULL,
    set_number integer NOT NULL,
    reps integer,
    weight_kg numeric(6,2),
    rpe numeric(3,1),
    completed boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workout_session_sets_reps_check CHECK (((reps IS NULL) OR (reps >= 0))),
    CONSTRAINT workout_session_sets_rpe_check CHECK (((rpe IS NULL) OR ((rpe >= (0)::numeric) AND (rpe <= (10)::numeric)))),
    CONSTRAINT workout_session_sets_set_number_check CHECK ((set_number > 0)),
    CONSTRAINT workout_session_sets_weight_kg_check CHECK (((weight_kg IS NULL) OR (weight_kg >= (0)::numeric)))
);


--
-- Name: workout_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workout_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    workout_plan_id uuid,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    feeling_score smallint,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT workout_sessions_check CHECK (((finished_at IS NULL) OR (finished_at >= started_at))),
    CONSTRAINT workout_sessions_feeling_score_check CHECK (((feeling_score IS NULL) OR ((feeling_score >= 1) AND (feeling_score <= 5))))
);


--
-- Name: exercise_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_categories ALTER COLUMN id SET DEFAULT nextval('public.exercise_categories_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
bfde54b0-906a-4eab-8bfa-c7cc6f3b7b81	137ccf88f7783efe480937b54ce7e0f837b76bb842d31fc9b5e707e9745726f0	2026-02-22 15:03:38.855427+00	202602220001_init_postgres_full		\N	2026-02-22 15:03:38.855427+00	0
\.


--
-- Data for Name: exercise_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercise_categories (id, slug, name) FROM stdin;
1	forca	Força
2	condicionamento	Condicionamento
3	mobilidade	Mobilidade
\.


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercises (id, category_id, name, equipment, is_unilateral, created_at) FROM stdin;
e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	Agachamento Livre	Barra Olímpica	f	2026-02-22 05:09:46.058+00
4e75244f-337c-4d01-8b5b-a0c580257b59	1	Supino Reto	Barra Olímpica	f	2026-02-22 05:09:46.06+00
b6733e3a-e99f-4dee-b919-6f2511bd09c1	1	Levantamento Terra	Barra Olímpica	f	2026-02-22 05:09:46.062+00
2a9f7879-9e15-4729-a266-4aba84a062a6	2	Remo Ergométrico	Remo Concept2	f	2026-02-22 05:09:46.063+00
71590990-7cb9-49cd-8743-c2bbda372334	2	Bike Intervalada	Bicicleta Ergométrica	f	2026-02-22 05:09:46.065+00
60421ef2-1cef-4c1f-9b40-959367e119a6	3	Mobilidade de Ombro	Faixa Elástica	f	2026-02-22 05:09:46.067+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, created_at) FROM stdin;
e25f46f4-8e7e-456a-9753-ee48e7579fd6	admin@treinododia.com	$2b$10$SPtuhxf75j.xyNM9xftt8eyXpHzAQAEaJrwTx8ZJKmndgVl56RJ7a	admin	2026-02-22 05:03:57.858+00
a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	cliente@treinododia.com	$2b$10$fMoQWYO5tE5FZFTu4WYAD.YMblqryhmFNYe8vVvsVD8Kd1ulqp1fq	user	2026-02-22 05:03:57.861+00
95bb9131-0487-41b3-b325-c7f859c2f2a4	joao.silva@treinododia.com	$2b$10$3Z1uet32J7hB7SDf.eIGqOBVJze5kVJZLtjEjFkciDfQlfftcdPje	user	2026-02-22 05:09:45.884+00
5bfabf39-dfdf-4f77-ac57-b5487c0a1118	maria.santos@treinododia.com	$2b$10$V7Zqv8mFzLjQsNQRaeOPtOU7H.30cn.akaGfunIUHMl4Izriqy13u	user	2026-02-22 05:09:45.962+00
fec4def5-b7c9-43fb-906e-dce9b3044318	ana.costa@treinododia.com	$2b$10$kHFRlqCbfpzBgjfWUYPgrue9k8fo73o.zjniZ7Xch8sujDdRBVbNC	user	2026-02-22 05:09:46.042+00
\.


--
-- Data for Name: workout_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_logs (id, user_id, workout_date, description, created_at, updated_at) FROM stdin;
60e38c5c-975a-4caa-9a29-a002b2648fb7	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	2026-02-13	Treino A: foco em técnica de agachamento e core.	2026-02-22 05:09:57.534+00	2026-02-22 05:09:57.534+00
fa12acdc-acae-4425-8c79-54157502c000	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	2026-02-16	Treino B: supino + puxadas com progressão de carga.	2026-02-22 05:09:57.534+00	2026-02-22 05:09:57.534+00
8f056473-4b81-4eee-b3ad-d34568540cde	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	2026-02-19	Treino C: condicionamento intervalado e mobilidade.	2026-02-22 05:09:57.534+00	2026-02-22 05:09:57.534+00
4ffd9263-be20-4b47-8c90-57574e428c14	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	2026-02-21	Treino D: sessão leve de recuperação ativa.	2026-02-22 05:09:57.534+00	2026-02-22 05:09:57.534+00
ebef5d58-504d-4e79-8e4c-6fb6d95f89fc	95bb9131-0487-41b3-b325-c7f859c2f2a4	2026-02-11	Treino A: foco em técnica de agachamento e core.	2026-02-22 05:09:57.546+00	2026-02-22 05:09:57.546+00
8233d362-b2e3-4a52-aae0-118f24bb2c5f	95bb9131-0487-41b3-b325-c7f859c2f2a4	2026-02-14	Treino B: supino + puxadas com progressão de carga.	2026-02-22 05:09:57.546+00	2026-02-22 05:09:57.546+00
307e7abc-745f-4b52-8b33-56acaea1ece3	95bb9131-0487-41b3-b325-c7f859c2f2a4	2026-02-17	Treino C: condicionamento intervalado e mobilidade.	2026-02-22 05:09:57.546+00	2026-02-22 05:09:57.546+00
528485f9-5ad4-487c-892c-5f1ec7a735a7	95bb9131-0487-41b3-b325-c7f859c2f2a4	2026-02-19	Treino D: sessão leve de recuperação ativa.	2026-02-22 05:09:57.546+00	2026-02-22 05:09:57.546+00
53e1c614-4bf1-4ea3-afd7-9d4ea8aca269	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	2026-02-09	Treino A: foco em técnica de agachamento e core.	2026-02-22 05:09:57.557+00	2026-02-22 05:09:57.557+00
1085fd8c-33f7-4b12-a807-82d679fd68d5	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	2026-02-12	Treino B: supino + puxadas com progressão de carga.	2026-02-22 05:09:57.557+00	2026-02-22 05:09:57.557+00
7b066db3-f55c-4592-af67-5be0dd0c0723	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	2026-02-15	Treino C: condicionamento intervalado e mobilidade.	2026-02-22 05:09:57.557+00	2026-02-22 05:09:57.557+00
64aa3bde-68f2-4e87-a7be-04188b7efb18	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	2026-02-17	Treino D: sessão leve de recuperação ativa.	2026-02-22 05:09:57.557+00	2026-02-22 05:09:57.557+00
75bad54c-3a77-4e78-9fb8-df82afb81f32	fec4def5-b7c9-43fb-906e-dce9b3044318	2026-02-07	Treino A: foco em técnica de agachamento e core.	2026-02-22 05:09:57.567+00	2026-02-22 05:09:57.567+00
daf09398-1986-4baa-9a63-4d6215835c5e	fec4def5-b7c9-43fb-906e-dce9b3044318	2026-02-10	Treino B: supino + puxadas com progressão de carga.	2026-02-22 05:09:57.567+00	2026-02-22 05:09:57.567+00
40013a5e-f509-4473-ab1c-461a6efc2c15	fec4def5-b7c9-43fb-906e-dce9b3044318	2026-02-13	Treino C: condicionamento intervalado e mobilidade.	2026-02-22 05:09:57.567+00	2026-02-22 05:09:57.567+00
b255ba74-4118-4c05-843f-287a16f41598	fec4def5-b7c9-43fb-906e-dce9b3044318	2026-02-15	Treino D: sessão leve de recuperação ativa.	2026-02-22 05:09:57.567+00	2026-02-22 05:09:57.567+00
\.


--
-- Data for Name: workout_plan_exercises; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_plan_exercises (id, workout_plan_id, exercise_id, sort_order, target_sets, target_reps_min, target_reps_max, target_weight_kg, rest_seconds, notes) FROM stdin;
5c8bc13e-ab43-4be4-aa4d-f3b26ddfe154	553e42ee-dd12-4867-9d24-be3527a6412d	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	4	5	6	80.00	150	\N
4ba873a5-be9b-4b2c-a8e8-c4df4a948ce5	553e42ee-dd12-4867-9d24-be3527a6412d	4e75244f-337c-4d01-8b5b-a0c580257b59	2	4	6	8	60.00	120	\N
08c15aa1-3b93-4852-9184-7c28b1f9aa40	553e42ee-dd12-4867-9d24-be3527a6412d	b6733e3a-e99f-4dee-b919-6f2511bd09c1	3	3	4	5	100.00	180	\N
16f7db6e-28ae-4b67-bcb2-d5ba4d25e8e6	9ba8e4a3-59c6-4723-b581-4da7b74f43f8	2a9f7879-9e15-4729-a266-4aba84a062a6	1	6	1	1	\N	60	Intervalos de 1min forte / 1min leve
4de21ff4-a6dd-47fe-b03e-76d5493cc401	9ba8e4a3-59c6-4723-b581-4da7b74f43f8	71590990-7cb9-49cd-8743-c2bbda372334	2	8	1	1	\N	45	\N
c9bf69c2-1d54-48be-979b-a1b192800388	9ba8e4a3-59c6-4723-b581-4da7b74f43f8	60421ef2-1cef-4c1f-9b40-959367e119a6	3	3	10	12	\N	30	\N
099bad00-4ba2-40cb-9c91-4212317bea49	b6d2720f-f62d-4236-9f5f-4752ab2b1b3d	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	4	5	6	85.00	150	\N
78803ffd-7d50-414a-9aab-e92221af7ab0	b6d2720f-f62d-4236-9f5f-4752ab2b1b3d	4e75244f-337c-4d01-8b5b-a0c580257b59	2	4	6	8	62.00	120	\N
32557f7c-6de4-48ed-b2ed-6c9ff2ccbf20	b6d2720f-f62d-4236-9f5f-4752ab2b1b3d	b6733e3a-e99f-4dee-b919-6f2511bd09c1	3	3	4	5	105.00	180	\N
3a66c484-2766-4f39-866f-9b68bd76569a	b7d8be15-f0b6-4705-a4e3-12b0cf138b92	2a9f7879-9e15-4729-a266-4aba84a062a6	1	6	1	1	\N	60	Intervalos de 1min forte / 1min leve
7ac92d43-6e7b-4bdb-a5f4-f80adc6dce3b	b7d8be15-f0b6-4705-a4e3-12b0cf138b92	71590990-7cb9-49cd-8743-c2bbda372334	2	8	1	1	\N	45	\N
aa872003-92e9-4139-96e3-cc9b4b71e544	b7d8be15-f0b6-4705-a4e3-12b0cf138b92	60421ef2-1cef-4c1f-9b40-959367e119a6	3	3	10	12	\N	30	\N
b4fd4dcc-5956-41ad-95eb-c290ac83dc6b	848a85c9-6b0e-4abd-ab74-99856062a8fc	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	4	5	6	90.00	150	\N
280fb412-1741-4040-926e-e804400a54d6	848a85c9-6b0e-4abd-ab74-99856062a8fc	4e75244f-337c-4d01-8b5b-a0c580257b59	2	4	6	8	64.00	120	\N
657910b4-858c-447c-90ee-7623321d4592	848a85c9-6b0e-4abd-ab74-99856062a8fc	b6733e3a-e99f-4dee-b919-6f2511bd09c1	3	3	4	5	110.00	180	\N
51a8d04e-bf64-47d7-8682-80cdb31722ce	1e0bbbe3-bf3d-4052-9c1b-84b1fc992d13	2a9f7879-9e15-4729-a266-4aba84a062a6	1	6	1	1	\N	60	Intervalos de 1min forte / 1min leve
46475339-c579-4c70-b349-37ba63eab8ff	1e0bbbe3-bf3d-4052-9c1b-84b1fc992d13	71590990-7cb9-49cd-8743-c2bbda372334	2	8	1	1	\N	45	\N
3a9ea8bb-c0b0-4c4d-b67b-cbec109311ef	1e0bbbe3-bf3d-4052-9c1b-84b1fc992d13	60421ef2-1cef-4c1f-9b40-959367e119a6	3	3	10	12	\N	30	\N
82d96fd1-dd00-4969-ba46-80bc1d4d1fa4	fe459540-2f94-4f81-9653-3479cceddc01	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	4	5	6	95.00	150	\N
2d12ea8a-e39d-46e8-a884-a3a519a11ee2	fe459540-2f94-4f81-9653-3479cceddc01	4e75244f-337c-4d01-8b5b-a0c580257b59	2	4	6	8	66.00	120	\N
2dd3cd80-8d7c-4977-bda8-062a11a45429	fe459540-2f94-4f81-9653-3479cceddc01	b6733e3a-e99f-4dee-b919-6f2511bd09c1	3	3	4	5	115.00	180	\N
963a94c8-5b6e-4e56-8225-ee72e02641ce	a395ea6a-d132-403d-9bc3-ea0a165cfda6	2a9f7879-9e15-4729-a266-4aba84a062a6	1	6	1	1	\N	60	Intervalos de 1min forte / 1min leve
ec0393ed-d1fd-4460-8d4a-12603ae9d8af	a395ea6a-d132-403d-9bc3-ea0a165cfda6	71590990-7cb9-49cd-8743-c2bbda372334	2	8	1	1	\N	45	\N
13e6566d-98fc-42b3-a2ad-9d6f47e93d54	a395ea6a-d132-403d-9bc3-ea0a165cfda6	60421ef2-1cef-4c1f-9b40-959367e119a6	3	3	10	12	\N	30	\N
\.


--
-- Data for Name: workout_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_plans (id, user_id, title, description, is_active, created_at, updated_at) FROM stdin;
553e42ee-dd12-4867-9d24-be3527a6412d	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	Plano Força 1	Ciclo de 4 semanas com progressão de carga em básicos.	t	2026-02-22 05:09:57.536+00	2026-02-22 05:09:57.536+00
9ba8e4a3-59c6-4723-b581-4da7b74f43f8	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	Plano Condicionamento 1	Sessões curtas de cardio intervalado e mobilidade.	t	2026-02-22 05:09:57.537+00	2026-02-22 05:09:57.537+00
b6d2720f-f62d-4236-9f5f-4752ab2b1b3d	95bb9131-0487-41b3-b325-c7f859c2f2a4	Plano Força 2	Ciclo de 4 semanas com progressão de carga em básicos.	t	2026-02-22 05:09:57.548+00	2026-02-22 05:09:57.548+00
b7d8be15-f0b6-4705-a4e3-12b0cf138b92	95bb9131-0487-41b3-b325-c7f859c2f2a4	Plano Condicionamento 2	Sessões curtas de cardio intervalado e mobilidade.	f	2026-02-22 05:09:57.549+00	2026-02-22 05:09:57.549+00
848a85c9-6b0e-4abd-ab74-99856062a8fc	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	Plano Força 3	Ciclo de 4 semanas com progressão de carga em básicos.	t	2026-02-22 05:09:57.558+00	2026-02-22 05:09:57.558+00
1e0bbbe3-bf3d-4052-9c1b-84b1fc992d13	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	Plano Condicionamento 3	Sessões curtas de cardio intervalado e mobilidade.	t	2026-02-22 05:09:57.56+00	2026-02-22 05:09:57.56+00
fe459540-2f94-4f81-9653-3479cceddc01	fec4def5-b7c9-43fb-906e-dce9b3044318	Plano Força 4	Ciclo de 4 semanas com progressão de carga em básicos.	t	2026-02-22 05:09:57.569+00	2026-02-22 05:09:57.569+00
a395ea6a-d132-403d-9bc3-ea0a165cfda6	fec4def5-b7c9-43fb-906e-dce9b3044318	Plano Condicionamento 4	Sessões curtas de cardio intervalado e mobilidade.	f	2026-02-22 05:09:57.57+00	2026-02-22 05:09:57.57+00
\.


--
-- Data for Name: workout_session_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_session_sets (id, workout_session_id, exercise_id, set_number, reps, weight_kg, rpe, completed, created_at) FROM stdin;
c254a814-f666-4520-a9e3-66df07e23414	10403be8-968b-4dd2-ae5d-60fcba7a29b3	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	6	80.00	7.5	t	2026-02-22 05:09:57.544+00
3274d05a-69c5-4988-b904-b014e33721a2	10403be8-968b-4dd2-ae5d-60fcba7a29b3	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	2	6	82.00	8.0	t	2026-02-22 05:09:57.544+00
28977b6d-67b0-481c-9cf2-4d55755a275f	10403be8-968b-4dd2-ae5d-60fcba7a29b3	4e75244f-337c-4d01-8b5b-a0c580257b59	1	8	60.00	7.0	t	2026-02-22 05:09:57.544+00
5910754a-f2c3-4626-b7e9-c6f3eb8bfa3a	d1db2ab2-e67b-43ba-a9f0-57cb4c32e36b	2a9f7879-9e15-4729-a266-4aba84a062a6	1	1	0.00	8.0	t	2026-02-22 05:09:57.544+00
ea71f137-27c9-4a27-8fca-12249dfa29f2	d1db2ab2-e67b-43ba-a9f0-57cb4c32e36b	71590990-7cb9-49cd-8743-c2bbda372334	1	1	0.00	8.5	t	2026-02-22 05:09:57.544+00
297ea058-bafd-4890-bb10-550b4b470ab4	f9839724-bb80-4a46-9743-cb9920884c64	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	6	85.00	7.5	t	2026-02-22 05:09:57.555+00
1fe4fb00-5bf9-46cc-b950-46800ca857ad	f9839724-bb80-4a46-9743-cb9920884c64	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	2	6	87.00	8.0	t	2026-02-22 05:09:57.555+00
b68bdf39-b68a-465f-b042-e61513adfd93	f9839724-bb80-4a46-9743-cb9920884c64	4e75244f-337c-4d01-8b5b-a0c580257b59	1	8	62.00	7.0	t	2026-02-22 05:09:57.555+00
3c4fbdce-a7a1-4928-a599-b292afbcbbe3	166a7011-dd61-4ca8-b540-52e87cc30fb6	2a9f7879-9e15-4729-a266-4aba84a062a6	1	1	0.00	8.0	t	2026-02-22 05:09:57.555+00
a7eb6e0b-4070-44c4-ab64-db247eabc090	166a7011-dd61-4ca8-b540-52e87cc30fb6	71590990-7cb9-49cd-8743-c2bbda372334	1	1	0.00	8.5	t	2026-02-22 05:09:57.555+00
5648dcd5-1566-4e0f-9025-a0184879e157	762dbc9a-0407-46de-84e2-96272381720d	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	6	90.00	7.5	t	2026-02-22 05:09:57.566+00
f6bfafe9-938d-4659-97e3-fd3e883f1420	762dbc9a-0407-46de-84e2-96272381720d	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	2	6	92.00	8.0	t	2026-02-22 05:09:57.566+00
fe7af2e6-e7b5-4c3b-bc83-d2309e334d8e	762dbc9a-0407-46de-84e2-96272381720d	4e75244f-337c-4d01-8b5b-a0c580257b59	1	8	64.00	7.0	t	2026-02-22 05:09:57.566+00
3d5ff5b8-b3b2-4583-b26c-db4bdd5d9682	ac83d168-aea3-4010-802c-2f8b5a15af37	2a9f7879-9e15-4729-a266-4aba84a062a6	1	1	0.00	8.0	t	2026-02-22 05:09:57.566+00
8abbe3d2-4cff-40a2-b08a-3930ccd1e9b8	ac83d168-aea3-4010-802c-2f8b5a15af37	71590990-7cb9-49cd-8743-c2bbda372334	1	1	0.00	8.5	t	2026-02-22 05:09:57.566+00
f5c86a1c-ca15-4330-9d27-c01384f3e10d	ac17f777-07fb-45c8-a516-78bd1f082261	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	1	6	95.00	7.5	t	2026-02-22 05:09:57.576+00
125501eb-2a75-40c8-8b87-2ff6ad116e8b	ac17f777-07fb-45c8-a516-78bd1f082261	e38e6946-debf-49ff-ba2c-8e0085ba4bb9	2	6	97.00	8.0	t	2026-02-22 05:09:57.576+00
e990374b-9b94-4c5f-b185-c234b9b15032	ac17f777-07fb-45c8-a516-78bd1f082261	4e75244f-337c-4d01-8b5b-a0c580257b59	1	8	66.00	7.0	t	2026-02-22 05:09:57.576+00
2bad8f07-51e6-4ade-b40a-048e56db0551	8c22f1a9-5ecb-4097-8e54-3ecc834c1b8e	2a9f7879-9e15-4729-a266-4aba84a062a6	1	1	0.00	8.0	t	2026-02-22 05:09:57.576+00
1bfbc528-f6f8-4b45-a63e-6d934f79abdb	8c22f1a9-5ecb-4097-8e54-3ecc834c1b8e	71590990-7cb9-49cd-8743-c2bbda372334	1	1	0.00	8.5	t	2026-02-22 05:09:57.576+00
\.


--
-- Data for Name: workout_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workout_sessions (id, user_id, workout_plan_id, started_at, finished_at, feeling_score, notes, created_at) FROM stdin;
10403be8-968b-4dd2-ae5d-60fcba7a29b3	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	553e42ee-dd12-4867-9d24-be3527a6412d	2026-02-20 05:09:57.54+00	2026-02-20 06:14:57.54+00	4	Boa execução técnica e progressão consistente.	2026-02-22 05:09:57.541+00
d1db2ab2-e67b-43ba-a9f0-57cb4c32e36b	a0bf3f83-8bb9-4c11-8acb-69bb1f7fa96c	9ba8e4a3-59c6-4723-b581-4da7b74f43f8	2026-02-22 05:09:57.54+00	2026-02-22 05:51:57.54+00	5	Sessão curta, alta intensidade e recuperação adequada.	2026-02-22 05:09:57.543+00
f9839724-bb80-4a46-9743-cb9920884c64	95bb9131-0487-41b3-b325-c7f859c2f2a4	b6d2720f-f62d-4236-9f5f-4752ab2b1b3d	2026-02-18 05:09:57.552+00	2026-02-18 06:14:57.552+00	4	Boa execução técnica e progressão consistente.	2026-02-22 05:09:57.552+00
166a7011-dd61-4ca8-b540-52e87cc30fb6	95bb9131-0487-41b3-b325-c7f859c2f2a4	b7d8be15-f0b6-4705-a4e3-12b0cf138b92	2026-02-20 05:09:57.552+00	2026-02-20 05:51:57.552+00	5	Sessão curta, alta intensidade e recuperação adequada.	2026-02-22 05:09:57.554+00
762dbc9a-0407-46de-84e2-96272381720d	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	848a85c9-6b0e-4abd-ab74-99856062a8fc	2026-02-16 05:09:57.562+00	2026-02-16 06:14:57.562+00	4	Boa execução técnica e progressão consistente.	2026-02-22 05:09:57.563+00
ac83d168-aea3-4010-802c-2f8b5a15af37	5bfabf39-dfdf-4f77-ac57-b5487c0a1118	1e0bbbe3-bf3d-4052-9c1b-84b1fc992d13	2026-02-18 05:09:57.562+00	2026-02-18 05:51:57.562+00	5	Sessão curta, alta intensidade e recuperação adequada.	2026-02-22 05:09:57.564+00
ac17f777-07fb-45c8-a516-78bd1f082261	fec4def5-b7c9-43fb-906e-dce9b3044318	fe459540-2f94-4f81-9653-3479cceddc01	2026-02-14 05:09:57.572+00	2026-02-14 06:14:57.572+00	4	Boa execução técnica e progressão consistente.	2026-02-22 05:09:57.573+00
8c22f1a9-5ecb-4097-8e54-3ecc834c1b8e	fec4def5-b7c9-43fb-906e-dce9b3044318	a395ea6a-d132-403d-9bc3-ea0a165cfda6	2026-02-16 05:09:57.572+00	2026-02-16 05:51:57.572+00	5	Sessão curta, alta intensidade e recuperação adequada.	2026-02-22 05:09:57.575+00
\.


--
-- Name: exercise_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exercise_categories_id_seq', 6, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: exercise_categories exercise_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_categories
    ADD CONSTRAINT exercise_categories_pkey PRIMARY KEY (id);


--
-- Name: exercise_categories exercise_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercise_categories
    ADD CONSTRAINT exercise_categories_slug_key UNIQUE (slug);


--
-- Name: exercises exercises_category_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_category_id_name_key UNIQUE (category_id, name);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workout_logs workout_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_logs
    ADD CONSTRAINT workout_logs_pkey PRIMARY KEY (id);


--
-- Name: workout_logs workout_logs_user_id_workout_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_logs
    ADD CONSTRAINT workout_logs_user_id_workout_date_key UNIQUE (user_id, workout_date);


--
-- Name: workout_plan_exercises workout_plan_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plan_exercises
    ADD CONSTRAINT workout_plan_exercises_pkey PRIMARY KEY (id);


--
-- Name: workout_plan_exercises workout_plan_exercises_workout_plan_id_sort_order_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plan_exercises
    ADD CONSTRAINT workout_plan_exercises_workout_plan_id_sort_order_key UNIQUE (workout_plan_id, sort_order);


--
-- Name: workout_plans workout_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plans
    ADD CONSTRAINT workout_plans_pkey PRIMARY KEY (id);


--
-- Name: workout_session_sets workout_session_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_session_sets
    ADD CONSTRAINT workout_session_sets_pkey PRIMARY KEY (id);


--
-- Name: workout_session_sets workout_session_sets_workout_session_id_exercise_id_set_num_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_session_sets
    ADD CONSTRAINT workout_session_sets_workout_session_id_exercise_id_set_num_key UNIQUE (workout_session_id, exercise_id, set_number);


--
-- Name: workout_sessions workout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_pkey PRIMARY KEY (id);


--
-- Name: idx_workout_logs_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_logs_user_date ON public.workout_logs USING btree (user_id, workout_date DESC);


--
-- Name: idx_workout_plan_exercises_exercise; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_plan_exercises_exercise ON public.workout_plan_exercises USING btree (exercise_id);


--
-- Name: idx_workout_plan_exercises_plan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_plan_exercises_plan ON public.workout_plan_exercises USING btree (workout_plan_id);


--
-- Name: idx_workout_plans_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_plans_user_id ON public.workout_plans USING btree (user_id);


--
-- Name: idx_workout_session_sets_exercise; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_session_sets_exercise ON public.workout_session_sets USING btree (exercise_id);


--
-- Name: idx_workout_session_sets_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_session_sets_session ON public.workout_session_sets USING btree (workout_session_id);


--
-- Name: idx_workout_sessions_plan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_sessions_plan ON public.workout_sessions USING btree (workout_plan_id);


--
-- Name: idx_workout_sessions_user_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workout_sessions_user_started ON public.workout_sessions USING btree (user_id, started_at DESC);


--
-- Name: exercises exercises_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.exercise_categories(id);


--
-- Name: workout_logs workout_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_logs
    ADD CONSTRAINT workout_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_plan_exercises workout_plan_exercises_exercise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plan_exercises
    ADD CONSTRAINT workout_plan_exercises_exercise_id_fkey FOREIGN KEY (exercise_id) REFERENCES public.exercises(id);


--
-- Name: workout_plan_exercises workout_plan_exercises_workout_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plan_exercises
    ADD CONSTRAINT workout_plan_exercises_workout_plan_id_fkey FOREIGN KEY (workout_plan_id) REFERENCES public.workout_plans(id) ON DELETE CASCADE;


--
-- Name: workout_plans workout_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_plans
    ADD CONSTRAINT workout_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_session_sets workout_session_sets_exercise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_session_sets
    ADD CONSTRAINT workout_session_sets_exercise_id_fkey FOREIGN KEY (exercise_id) REFERENCES public.exercises(id);


--
-- Name: workout_session_sets workout_session_sets_workout_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_session_sets
    ADD CONSTRAINT workout_session_sets_workout_session_id_fkey FOREIGN KEY (workout_session_id) REFERENCES public.workout_sessions(id) ON DELETE CASCADE;


--
-- Name: workout_sessions workout_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_sessions workout_sessions_workout_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_workout_plan_id_fkey FOREIGN KEY (workout_plan_id) REFERENCES public.workout_plans(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict zuGNDXh2MSiZRiXW3MXfXvhtLFggfzjUnv1I1teTSCKUxhVDyLVhUJNckoe5DLr

